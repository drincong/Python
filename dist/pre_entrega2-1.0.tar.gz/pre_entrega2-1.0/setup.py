from setuptools import setup

setup(
      name="Pre_Entrega2",
      version="1.0",
      description="Paquete de la segunda pre entrega incluyendo dentro del mismo la primera.",
      author="Diego Fernando Rincón Guevara",
      author_email="df_rincong@hotmail.com",
      
      packages= ["Pre_Entrega2"]
      
     )
